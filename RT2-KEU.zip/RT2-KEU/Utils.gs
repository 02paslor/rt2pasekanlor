/**
 * Utils.gs
 * Fungsi bantu umum: response standar, hashing password, validasi,
 * pencatatan aktivitas, dan format tanggal/angka sisi server.
 */

function successResponse(data, message) {
  return { success: true, data: (data !== undefined ? data : null), message: message || '' };
}

function errorResponse(message) {
  return { success: false, data: null, message: message || 'Terjadi kesalahan. Silakan coba lagi.' };
}

function handleServerError(e, context) {
  Logger.log('[' + (context || 'ERROR') + '] ' + (e && e.stack ? e.stack : e));
  if (e && e.message === 'AUTH_REQUIRED') return errorResponse('Sesi Anda telah berakhir. Silakan login kembali.');
  if (e && e.message === 'AUTH_FORBIDDEN') return errorResponse('Anda tidak memiliki akses untuk melakukan aksi ini.');
  if (e && e.userMessage) return errorResponse(e.userMessage);
  return errorResponse('Terjadi kesalahan. Silakan coba lagi.');
}

function timestampNow() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Jakarta', "yyyy-MM-dd'T'HH:mm:ss");
}

function todayString() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM-dd');
}

function maskNIK(nik) {
  if (!nik) return '-';
  var s = String(nik);
  if (s.length <= 3) return s;
  var maskLen = s.length - 3;
  return s.substring(0, 3) + new Array(maskLen + 1).join('x');
}

function sha256Hex(input) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, input, Utilities.Charset.UTF_8);
  return bytes.map(function (b) {
    var v = (b < 0 ? b + 256 : b).toString(16);
    return v.length === 1 ? '0' + v : v;
  }).join('');
}

function hashPasswordWithSalt(password, salt) {
  return sha256Hex(salt + '::' + password);
}

function createPasswordHash(password) {
  var salt = Utilities.getUuid().replace(/-/g, '').substring(0, 16);
  var hash = hashPasswordWithSalt(password, salt);
  return salt + '$' + hash;
}

function verifyPasswordHash(password, stored) {
  if (!stored || String(stored).indexOf('$') === -1) return false;
  var parts = String(stored).split('$');
  return hashPasswordWithSalt(password, parts[0]) === parts[1];
}

/**
 * Melempar error dengan pesan ramah-pengguna (userMessage) yang dijamin
 * ditampilkan ke frontend, terpisah dari pesan teknis di Logger.
 */
function userError(message) {
  var e = new Error(message);
  e.userMessage = message;
  return e;
}

function validateRequired(obj, fields) {
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var v = obj ? obj[f] : undefined;
    if (v === undefined || v === null || String(v).trim() === '') {
      throw userError('Field "' + f + '" wajib diisi.');
    }
  }
}

function isValidNumberValue(v) {
  return v !== '' && v !== null && v !== undefined && !isNaN(Number(v));
}

function isValidDateStringValue(v) {
  if (!v) return false;
  return !isNaN(Date.parse(v));
}

function paginateArray(arr, page, pageSize) {
  page = Number(page) || 1;
  pageSize = Number(pageSize) || 10;
  var total = arr.length;
  var totalPages = Math.max(1, Math.ceil(total / pageSize));
  if (page > totalPages) page = totalPages;
  var start = (page - 1) * pageSize;
  var data = arr.slice(start, start + pageSize);
  return { data: data, total: total, page: page, pageSize: pageSize, totalPages: totalPages };
}

function textMatches(haystack, needle) {
  if (!needle) return true;
  if (!haystack) return false;
  return String(haystack).toLowerCase().indexOf(String(needle).toLowerCase()) !== -1;
}

function logActivity(username, action, module, description) {
  try {
    withLock(function () {
      var id = generateIdUnlocked(ID_PREFIX.LOG);
      var sheet = getSheet(SHEET_NAMES.ACTIVITY_LOG);
      sheet.appendRow([id, username || 'system', action, module, description, timestampNow()]);
    });
  } catch (e) {
    Logger.log('Gagal mencatat activity log: ' + e);
  }
}
