/**
 * Warga.gs
 * CRUD data warga, ringkasan per kepala keluarga, dan pencatatan mutasi
 * (warga masuk/keluar/pindah/meninggal).
 */

var WARGA_REQUIRED_FIELDS = ['no_kk', 'nik', 'nama_lengkap', 'jenis_kelamin', 'status_dalam_keluarga', 'alamat', 'status_warga'];

function sanitizeWargaForList_(w, level) {
  return {
    id: w.id, no_kk: w.no_kk, nik: maskNIK(w.nik), nama_lengkap: w.nama_lengkap,
    jenis_kelamin: w.jenis_kelamin, status_dalam_keluarga: w.status_dalam_keluarga,
    no_hp: w.no_hp, alamat: w.alamat, status_warga: w.status_warga,
    tanggal_lahir: w.tanggal_lahir
  };
}

function getWargaList(token, opts) {
  try {
    requireAuth(token, 'warga', 1);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.WARGA);
    items = items.filter(function (w) {
      if (opts.search && !(textMatches(w.nama_lengkap, opts.search) || textMatches(w.no_kk, opts.search) || textMatches(w.alamat, opts.search))) return false;
      if (opts.status_warga && w.status_warga !== opts.status_warga) return false;
      if (opts.jenis_kelamin && w.jenis_kelamin !== opts.jenis_kelamin) return false;
      return true;
    });
    items.sort(function (a, b) { return String(a.nama_lengkap).localeCompare(String(b.nama_lengkap)); });
    var mapped = items.map(function (w) { return sanitizeWargaForList_(w); });
    var result = paginateArray(mapped, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getWargaList');
  }
}

function getWargaDetail(token, id) {
  try {
    var session = requireAuth(token, 'warga', 1);
    var w = findObjectById(SHEET_NAMES.WARGA, id);
    if (!w) return errorResponse('Data warga tidak ditemukan.');
    var level = (ROLE_PERMISSIONS[session.role] || {}).warga || 0;
    var detail = {};
    for (var key in w) detail[key] = w[key];
    if (level < 2) {
      detail.nik = maskNIK(w.nik);
      detail.no_hp = w.no_hp ? maskNIK(w.no_hp) : '';
    }
    return successResponse(detail);
  } catch (e) {
    return handleServerError(e, 'getWargaDetail');
  }
}

function addWarga(token, data) {
  try {
    var session = requireAuth(token, 'warga', 2);
    validateRequired(data, WARGA_REQUIRED_FIELDS);
    if (data.tanggal_lahir && !isValidDateStringValue(data.tanggal_lahir)) throw userError('Tanggal lahir tidak valid.');

    var obj = withLock(function () {
      var id = generateIdUnlocked(ID_PREFIX.WARGA);
      var row = {
        id: id, no_kk: data.no_kk, nik: data.nik, nama_lengkap: data.nama_lengkap,
        jenis_kelamin: data.jenis_kelamin, tempat_lahir: data.tempat_lahir || '',
        tanggal_lahir: data.tanggal_lahir || '', status_perkawinan: data.status_perkawinan || '',
        agama: data.agama || '', pendidikan: data.pendidikan || '', pekerjaan: data.pekerjaan || '',
        status_dalam_keluarga: data.status_dalam_keluarga, no_hp: data.no_hp || '', alamat: data.alamat,
        rt: data.rt || '05', rw: data.rw || '', status_warga: data.status_warga,
        tanggal_masuk: data.tanggal_masuk || todayString(), tanggal_keluar: '',
        keterangan: data.keterangan || '', created_at: timestampNow(), updated_at: timestampNow()
      };
      insertObjectUnlocked(SHEET_NAMES.WARGA, row);
      return row;
    });

    logActivity(session.username, 'Tambah', 'Warga', session.nama + ' menambahkan warga ' + data.nama_lengkap);
    return successResponse({ id: obj.id }, 'Data warga berhasil disimpan.');
  } catch (e) {
    return handleServerError(e, 'addWarga');
  }
}

function updateWarga(token, id, data) {
  try {
    var session = requireAuth(token, 'warga', 2);
    validateRequired(data, WARGA_REQUIRED_FIELDS);
    var existing = findObjectById(SHEET_NAMES.WARGA, id);
    if (!existing) return errorResponse('Data warga tidak ditemukan.');

    var updates = {
      no_kk: data.no_kk, nik: data.nik, nama_lengkap: data.nama_lengkap, jenis_kelamin: data.jenis_kelamin,
      tempat_lahir: data.tempat_lahir || '', tanggal_lahir: data.tanggal_lahir || '',
      status_perkawinan: data.status_perkawinan || '', agama: data.agama || '', pendidikan: data.pendidikan || '',
      pekerjaan: data.pekerjaan || '', status_dalam_keluarga: data.status_dalam_keluarga, no_hp: data.no_hp || '',
      alamat: data.alamat, rt: data.rt || '05', rw: data.rw || '', status_warga: data.status_warga,
      keterangan: data.keterangan || '', updated_at: timestampNow()
    };
    updateObjectById(SHEET_NAMES.WARGA, id, updates);
    logActivity(session.username, 'Ubah', 'Warga', session.nama + ' memperbarui data warga ' + data.nama_lengkap);
    return successResponse({}, 'Data warga berhasil diperbarui.');
  } catch (e) {
    return handleServerError(e, 'updateWarga');
  }
}

function deleteWarga(token, id) {
  try {
    var session = requireAuth(token, 'warga', 2);
    var existing = findObjectById(SHEET_NAMES.WARGA, id);
    if (!existing) return errorResponse('Data warga tidak ditemukan.');
    deleteObjectById(SHEET_NAMES.WARGA, id);
    logActivity(session.username, 'Hapus', 'Warga', session.nama + ' menghapus data warga ' + existing.nama_lengkap);
    return successResponse({}, 'Data warga berhasil dihapus.');
  } catch (e) {
    return handleServerError(e, 'deleteWarga');
  }
}

/** Mengelompokkan warga per no_kk untuk halaman Daftar Kepala Keluarga. */
function getKeluargaList(token, opts) {
  try {
    requireAuth(token, 'warga', 1);
    opts = opts || {};
    var warga = sheetToObjects(SHEET_NAMES.WARGA);
    var jimpitanRows = sheetToObjects(SHEET_NAMES.JIMPITAN);
    var thisMonth = todayString().substring(0, 7);

    var groups = {};
    warga.forEach(function (w) {
      if (!groups[w.no_kk]) groups[w.no_kk] = { no_kk: w.no_kk, anggota: [], kepala: null };
      groups[w.no_kk].anggota.push(w);
      if (w.status_dalam_keluarga === 'Kepala Keluarga') groups[w.no_kk].kepala = w;
    });

    var list = Object.keys(groups).map(function (kk) {
      var g = groups[kk];
      var kepala = g.kepala || g.anggota[0];
      var jimpitanBulanIni = jimpitanRows.filter(function (j) {
        return j.no_kk === kk && String(j.tanggal).substring(0, 7) === thisMonth;
      });
      var sudahSetor = jimpitanBulanIni.some(function (j) { return j.status === 'Lunas'; });
      return {
        no_kk: kk,
        nama_kepala_keluarga: kepala ? kepala.nama_lengkap : '-',
        jumlah_anggota: g.anggota.length,
        alamat: kepala ? kepala.alamat : '',
        no_hp: kepala ? kepala.no_hp : '',
        status_warga: kepala ? kepala.status_warga : '',
        status_jimpitan_bulan_ini: sudahSetor ? 'Sudah Setor' : 'Belum Setor'
      };
    });

    if (opts.search) {
      list = list.filter(function (g) {
        return textMatches(g.nama_kepala_keluarga, opts.search) || textMatches(g.no_kk, opts.search);
      });
    }
    list.sort(function (a, b) { return String(a.nama_kepala_keluarga).localeCompare(String(b.nama_kepala_keluarga)); });

    var result = paginateArray(list, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getKeluargaList');
  }
}

function getKeluargaDetail(token, no_kk) {
  try {
    var session = requireAuth(token, 'warga', 1);
    var level = (ROLE_PERMISSIONS[session.role] || {}).warga || 0;
    var warga = sheetToObjects(SHEET_NAMES.WARGA).filter(function (w) { return w.no_kk === no_kk; });
    if (warga.length === 0) return errorResponse('Kepala keluarga tidak ditemukan.');
    var anggota = warga.map(function (w) {
      var copy = {};
      for (var k in w) copy[k] = w[k];
      if (level < 2) copy.nik = maskNIK(w.nik);
      return copy;
    });
    return successResponse({ no_kk: no_kk, anggota: anggota });
  } catch (e) {
    return handleServerError(e, 'getKeluargaDetail');
  }
}

function addMutasi(token, data) {
  try {
    var session = requireAuth(token, 'warga', 2);
    validateRequired(data, ['warga_id', 'jenis_mutasi', 'tanggal']);
    var warga = findObjectById(SHEET_NAMES.WARGA, data.warga_id);
    if (!warga) return errorResponse('Data warga tidak ditemukan.');
    if (!isValidDateStringValue(data.tanggal)) throw userError('Tanggal mutasi tidak valid.');

    var statusMap = { 'Keluar': 'Pindah', 'Pindah': 'Pindah', 'Meninggal': 'Meninggal', 'Masuk': 'Tetap' };
    var newStatus = statusMap[data.jenis_mutasi] || warga.status_warga;

    var mutasiId = withLock(function () {
      var id = generateIdUnlocked(ID_PREFIX.MUTASI);
      insertObjectUnlocked(SHEET_NAMES.MUTASI_WARGA, {
        id: id, warga_id: data.warga_id, jenis_mutasi: data.jenis_mutasi, tanggal: data.tanggal,
        alasan: data.alasan || '', tujuan: data.tujuan || '', keterangan: data.keterangan || '',
        created_by: session.nama, created_at: timestampNow()
      });
      var wargaUpdates = { status_warga: newStatus, updated_at: timestampNow() };
      if (data.jenis_mutasi === 'Keluar' || data.jenis_mutasi === 'Pindah' || data.jenis_mutasi === 'Meninggal') {
        wargaUpdates.tanggal_keluar = data.tanggal;
      }
      updateObjectByIdUnlocked(SHEET_NAMES.WARGA, data.warga_id, wargaUpdates);
      return id;
    });

    logActivity(session.username, 'Mutasi', 'Warga', session.nama + ' mencatat mutasi ' + data.jenis_mutasi + ' untuk ' + warga.nama_lengkap);
    return successResponse({ id: mutasiId }, 'Mutasi warga berhasil dicatat.');
  } catch (e) {
    return handleServerError(e, 'addMutasi');
  }
}

function getMutasiList(token, opts) {
  try {
    requireAuth(token, 'warga', 1);
    opts = opts || {};
    var warga = sheetToObjects(SHEET_NAMES.WARGA);
    var wargaMap = {};
    warga.forEach(function (w) { wargaMap[w.id] = w; });

    var items = sheetToObjects(SHEET_NAMES.MUTASI_WARGA).map(function (m) {
      var w = wargaMap[m.warga_id];
      return {
        id: m.id, warga_id: m.warga_id, nama_warga: w ? w.nama_lengkap : '-',
        no_kk: w ? w.no_kk : '-', jenis_mutasi: m.jenis_mutasi, tanggal: m.tanggal,
        alasan: m.alasan, tujuan: m.tujuan, keterangan: m.keterangan, created_by: m.created_by
      };
    });

    if (opts.jenis_mutasi) items = items.filter(function (m) { return m.jenis_mutasi === opts.jenis_mutasi; });
    if (opts.search) items = items.filter(function (m) { return textMatches(m.nama_warga, opts.search); });

    items.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });
    var result = paginateArray(items, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getMutasiList');
  }
}

function getMutasiDashboard(token) {
  try {
    requireAuth(token, 'warga', 1);
    var thisMonth = todayString().substring(0, 7);
    var mutasi = sheetToObjects(SHEET_NAMES.MUTASI_WARGA);
    var masuk = 0, keluar = 0;
    mutasi.forEach(function (m) {
      if (String(m.tanggal).substring(0, 7) !== thisMonth) return;
      if (m.jenis_mutasi === 'Masuk') masuk++;
      else keluar++;
    });
    return successResponse({ masuk_bulan_ini: masuk, keluar_bulan_ini: keluar });
  } catch (e) {
    return handleServerError(e, 'getMutasiDashboard');
  }
}
