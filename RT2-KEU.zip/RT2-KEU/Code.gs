/**
 * Code.gs
 * Entry point Web App. Menyajikan shell SPA (index.html) dan helper include()
 * untuk menggabungkan partial HTML/CSS/JS. Status setup & login ditentukan
 * di sisi client lewat checkSetupStatus() / validateSession() agar tidak perlu
 * reload halaman penuh saat berpindah state.
 */

function doGet(e) {
  var template = HtmlService.createTemplateFromFile('index');
  template.appName = APP_NAME;
  template.appSubtitle = APP_SUBTITLE;
  template.appFooter = APP_FOOTER;
  return template.evaluate()
    .setTitle(APP_NAME + ' - Sistem Administrasi RT')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/**
 * Mengisi data contoh yang jelas ditandai DEMO. Hanya bisa dijalankan Admin,
 * dan hanya jika pengguna secara eksplisit memilih "Isi Data Contoh".
 * Tidak pernah dijalankan otomatis terhadap database produksi.
 */
function seedDemoData(token) {
  try {
    var session = requireAuth(token, 'settings', 2);

    var kkList = [
      { no_kk: '3404010000010001', nama: 'Budi Santoso (Contoh)', jk: 'Laki-laki', hp: '081200000001' },
      { no_kk: '3404010000010002', nama: 'Sumarno (Contoh)', jk: 'Laki-laki', hp: '081200000002' },
      { no_kk: '3404010000010003', nama: 'Andi Wijaya (Contoh)', jk: 'Laki-laki', hp: '081200000003' },
      { no_kk: '3404010000010004', nama: 'Siti Aminah (Contoh)', jk: 'Perempuan', hp: '081200000004' },
      { no_kk: '3404010000010005', nama: 'Hartono (Contoh)', jk: 'Laki-laki', hp: '081200000005' }
    ];

    var wargaIds = [];
    withLock(function () {
      kkList.forEach(function (kk, idx) {
        var id = generateIdUnlocked(ID_PREFIX.WARGA);
        wargaIds.push({ id: id, no_kk: kk.no_kk, nama: kk.nama });
        insertObjectUnlocked(SHEET_NAMES.WARGA, {
          id: id, no_kk: kk.no_kk, nik: '34040105' + (90000000 + idx * 111).toString(),
          nama_lengkap: kk.nama, jenis_kelamin: kk.jk, tempat_lahir: 'Sleman',
          tanggal_lahir: '1985-0' + (idx + 1) + '-15', status_perkawinan: 'Kawin', agama: 'Islam',
          pendidikan: 'SMA', pekerjaan: 'Wiraswasta', status_dalam_keluarga: 'Kepala Keluarga',
          no_hp: kk.hp, alamat: 'Kwarasan RT 05 No. ' + (idx + 1), rt: '05', rw: '20',
          status_warga: 'Tetap', tanggal_masuk: '2015-01-01', tanggal_keluar: '',
          keterangan: 'Data Contoh (DEMO)', created_at: timestampNow(), updated_at: timestampNow()
        });
        var anggotaId = generateIdUnlocked(ID_PREFIX.WARGA);
        insertObjectUnlocked(SHEET_NAMES.WARGA, {
          id: anggotaId, no_kk: kk.no_kk, nik: '34040105' + (90000500 + idx * 111).toString(),
          nama_lengkap: kk.nama.replace('(Contoh)', 'Istri (Contoh)'), jenis_kelamin: 'Perempuan',
          tempat_lahir: 'Sleman', tanggal_lahir: '1987-0' + (idx + 1) + '-10', status_perkawinan: 'Kawin',
          agama: 'Islam', pendidikan: 'SMA', pekerjaan: 'Ibu Rumah Tangga', status_dalam_keluarga: 'Istri',
          no_hp: '', alamat: 'Kwarasan RT 05 No. ' + (idx + 1), rt: '05', rw: '20',
          status_warga: 'Tetap', tanggal_masuk: '2015-01-01', tanggal_keluar: '',
          keterangan: 'Data Contoh (DEMO)', created_at: timestampNow(), updated_at: timestampNow()
        });
      });

      var nominal = Number(getSettingValue('jimpitan_nominal', 1000)) || 1000;
      var today = todayString();
      wargaIds.forEach(function (w, idx) {
        var sudahSetor = idx < 3;
        var jId = generateIdUnlocked(ID_PREFIX.JIMPITAN);
        insertObjectUnlocked(SHEET_NAMES.JIMPITAN, {
          id: jId, tanggal: today, warga_id: w.id, no_kk: w.no_kk, nama_kepala_keluarga: w.nama,
          nominal: sudahSetor ? nominal : 0, metode: 'Tunai', status: sudahSetor ? 'Lunas' : 'Belum Bayar',
          petugas: session.nama, keterangan: 'Data Contoh (DEMO)', created_at: timestampNow(), updated_at: timestampNow()
        });
      });

      var kasIn = generateIdUnlocked(ID_PREFIX.KAS);
      insertObjectUnlocked(SHEET_NAMES.KAS, {
        id: kasIn, tanggal: today, jenis: 'Pemasukan', kategori: 'Iuran', nominal: 150000,
        sumber_tujuan: 'Iuran warga (Contoh)', keterangan: 'Data Contoh (DEMO)', bukti: '', kegiatan_id: '',
        created_by: session.nama, created_at: timestampNow()
      });
      var kasOut = generateIdUnlocked(ID_PREFIX.KAS);
      insertObjectUnlocked(SHEET_NAMES.KAS, {
        id: kasOut, tanggal: today, jenis: 'Pengeluaran', kategori: 'Kebersihan', nominal: 50000,
        sumber_tujuan: 'Beli alat kebersihan (Contoh)', keterangan: 'Data Contoh (DEMO)', bukti: '', kegiatan_id: '',
        created_by: session.nama, created_at: timestampNow()
      });

      var ktgId = generateIdUnlocked(ID_PREFIX.KEGIATAN);
      insertObjectUnlocked(SHEET_NAMES.KEGIATAN, {
        id: ktgId, nama_kegiatan: 'Kerja Bakti (Contoh)', tanggal: today, waktu: '07:00',
        lokasi: 'Lapangan RT 05', penanggung_jawab: session.nama, anggaran: 200000, status: 'Rencana',
        deskripsi: 'Kegiatan contoh untuk keperluan uji coba (DEMO).', created_at: timestampNow(), updated_at: timestampNow()
      });
    });

    logActivity(session.username, 'Isi Data Contoh', 'Sistem', session.nama + ' mengisi data contoh (DEMO)');
    return successResponse({}, 'Data contoh berhasil ditambahkan.');
  } catch (e) {
    return handleServerError(e, 'seedDemoData');
  }
}
