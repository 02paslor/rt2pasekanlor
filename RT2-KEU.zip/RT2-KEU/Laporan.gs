/**
 * Laporan.gs
 * Agregasi laporan warga & kegiatan, serta export CSV untuk seluruh modul
 * (warga, jimpitan, keuangan, kegiatan). Laporan jimpitan & keuangan memakai
 * fungsi rekap yang sudah ada di Jimpitan.gs / Kas.gs.
 */

function calculateAge_(tanggalLahir) {
  if (!tanggalLahir || !isValidDateStringValue(tanggalLahir)) return null;
  var dob = new Date(tanggalLahir);
  var today = new Date();
  var age = today.getFullYear() - dob.getFullYear();
  var m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

function getLaporanWarga(token) {
  try {
    requireAuth(token, 'warga', 1);
    var warga = sheetToObjects(SHEET_NAMES.WARGA);
    var aktif = warga.filter(function (w) { return w.status_warga !== 'Pindah' && w.status_warga !== 'Meninggal'; });
    var lakiLaki = 0, perempuan = 0, anak = 0, lansia = 0, pendatang = 0, pindah = 0, meninggal = 0;
    var kkSet = {};

    warga.forEach(function (w) {
      if (w.status_warga === 'Pindah') pindah++;
      if (w.status_warga === 'Meninggal') meninggal++;
      if (w.status_warga === 'Pendatang') pendatang++;
    });

    aktif.forEach(function (w) {
      if (w.jenis_kelamin === 'Laki-laki') lakiLaki++;
      else if (w.jenis_kelamin === 'Perempuan') perempuan++;
      kkSet[w.no_kk] = true;
      var umur = calculateAge_(w.tanggal_lahir);
      if (umur !== null) {
        if (umur < 17) anak++;
        if (umur >= 60) lansia++;
      }
    });

    return successResponse({
      total_warga: aktif.length, laki_laki: lakiLaki, perempuan: perempuan,
      total_kk: Object.keys(kkSet).length, anak_anak: anak, lansia: lansia,
      pendatang: pendatang, warga_pindah: pindah, warga_meninggal: meninggal
    });
  } catch (e) {
    return handleServerError(e, 'getLaporanWarga');
  }
}

function getLaporanKegiatan(token, opts) {
  try {
    requireAuth(token, 'kegiatan', 1);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.KEGIATAN);
    items = items.filter(function (k) {
      if (opts.status && k.status !== opts.status) return false;
      if (opts.bulan && String(k.tanggal).substring(0, 7) !== opts.bulan) return false;
      if (opts.tahun && String(k.tanggal).substring(0, 4) !== String(opts.tahun)) return false;
      return true;
    });

    var byStatus = { Rencana: 0, Berjalan: 0, Selesai: 0, Dibatalkan: 0 };
    var totalAnggaran = 0;
    items.forEach(function (k) {
      byStatus[k.status] = (byStatus[k.status] || 0) + 1;
      totalAnggaran += Number(k.anggaran) || 0;
    });

    var list = items.map(function (k) {
      var realisasi = getKasTotalByKegiatan_(k.id);
      return {
        id: k.id, nama_kegiatan: k.nama_kegiatan, tanggal: k.tanggal, status: k.status,
        anggaran: Number(k.anggaran) || 0, realisasi: realisasi.total
      };
    });
    list.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });

    return successResponse({ total_kegiatan: items.length, by_status: byStatus, total_anggaran: totalAnggaran, list: list });
  } catch (e) {
    return handleServerError(e, 'getLaporanKegiatan');
  }
}

function csvEscape_(val) {
  if (val === null || val === undefined) val = '';
  val = String(val);
  if (val.indexOf(',') !== -1 || val.indexOf('"') !== -1 || val.indexOf('\n') !== -1) {
    val = '"' + val.replace(/"/g, '""') + '"';
  }
  return val;
}

function buildCsv_(headers, rows) {
  var lines = [headers.map(csvEscape_).join(',')];
  rows.forEach(function (row) { lines.push(row.map(csvEscape_).join(',')); });
  return lines.join('\n');
}

/** Menghasilkan konten CSV untuk diunduh di sisi client (Apps Script tidak memicu download server-side). */
function exportCSV(token, type, params) {
  try {
    var gateMap = {
      warga: { module: 'warga', level: 1 },
      jimpitan: { module: 'jimpitan', level: 1 },
      keuangan: { module: 'laporan', level: 2 },
      kegiatan: { module: 'kegiatan', level: 1 }
    };
    var gate = gateMap[type];
    if (!gate) return errorResponse('Jenis laporan tidak dikenal.');
    var session = requireAuth(token, gate.module, gate.level);
    params = params || {};
    var content = '', filename = '';
    var period = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM');

    if (type === 'warga') {
      var warga = sheetToObjects(SHEET_NAMES.WARGA);
      var headers = ['No KK', 'NIK', 'Nama Lengkap', 'Jenis Kelamin', 'Status Dalam Keluarga', 'No HP', 'Alamat', 'Status Warga'];
      var rows = warga.map(function (w) {
        return [w.no_kk, w.nik, w.nama_lengkap, w.jenis_kelamin, w.status_dalam_keluarga, w.no_hp, w.alamat, w.status_warga];
      });
      content = buildCsv_(headers, rows);
      filename = 'laporan-warga-' + period + '.csv';
    } else if (type === 'jimpitan') {
      var jimpitan = sheetToObjects(SHEET_NAMES.JIMPITAN);
      if (params.bulan) jimpitan = jimpitan.filter(function (j) { return String(j.tanggal).substring(0, 7) === params.bulan; });
      var headers2 = ['Tanggal', 'No KK', 'Kepala Keluarga', 'Nominal', 'Metode', 'Status', 'Petugas'];
      var rows2 = jimpitan.map(function (j) {
        return [j.tanggal, j.no_kk, j.nama_kepala_keluarga, j.nominal, j.metode, j.status, j.petugas];
      });
      content = buildCsv_(headers2, rows2);
      filename = 'laporan-jimpitan-' + (params.bulan || period) + '.csv';
    } else if (type === 'keuangan') {
      var kas = sheetToObjects(SHEET_NAMES.KAS);
      if (params.bulan) kas = kas.filter(function (k) { return String(k.tanggal).substring(0, 7) === params.bulan; });
      var headers3 = ['Tanggal', 'Jenis', 'Kategori', 'Nominal', 'Sumber/Tujuan', 'Keterangan', 'Dicatat Oleh'];
      var rows3 = kas.map(function (k) {
        return [k.tanggal, k.jenis, k.kategori, k.nominal, k.sumber_tujuan, k.keterangan, k.created_by];
      });
      content = buildCsv_(headers3, rows3);
      filename = 'laporan-keuangan-' + (params.bulan || period) + '.csv';
    } else if (type === 'kegiatan') {
      var kegiatan = sheetToObjects(SHEET_NAMES.KEGIATAN);
      var headers4 = ['Nama Kegiatan', 'Tanggal', 'Waktu', 'Lokasi', 'Penanggung Jawab', 'Anggaran', 'Status'];
      var rows4 = kegiatan.map(function (k) {
        return [k.nama_kegiatan, k.tanggal, k.waktu, k.lokasi, k.penanggung_jawab, k.anggaran, k.status];
      });
      content = buildCsv_(headers4, rows4);
      filename = 'laporan-kegiatan-' + period + '.csv';
    } else {
      return errorResponse('Jenis laporan tidak dikenal.');
    }

    logActivity(session.username, 'Export CSV', 'Laporan', session.nama + ' mengekspor laporan ' + type + ' ke CSV');
    return successResponse({ content: content, filename: filename });
  } catch (e) {
    return handleServerError(e, 'exportCSV');
  }
}
