/**
 * Database.gs
 * Lapisan akses data ke Google Sheets. Semua modul (Warga, Jimpitan, Kas, dst)
 * membaca/menulis lewat fungsi di file ini agar konsisten dan aman terhadap
 * akses bersamaan (LockService) serta hemat pemanggilan SpreadsheetApp.
 */

function ensureSheetExists_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#DCEAF3').setFontColor('#344054');
    sheet.setColumnWidths(1, headers.length, 140);
  } else {
    var lastCol = Math.max(sheet.getLastColumn(), 1);
    var existing = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var toAdd = headers.filter(function (h) { return existing.indexOf(h) === -1; });
    if (toAdd.length > 0) {
      sheet.getRange(1, existing.length + 1, 1, toAdd.length).setValues([toAdd]);
      sheet.getRange(1, existing.length + 1, 1, toAdd.length).setFontWeight('bold').setBackground('#DCEAF3');
    }
  }
  return sheet;
}

/**
 * Membuat seluruh sheet yang dibutuhkan aplikasi jika belum ada.
 * Tidak pernah menghapus data yang sudah ada.
 */
function initializeDatabase() {
  var ss = getActiveSpreadsheet();
  Object.keys(SHEET_NAMES).forEach(function (key) {
    ensureSheetExists_(ss, SHEET_NAMES[key], SHEET_HEADERS[key]);
  });
  var defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && ss.getSheets().length > 1 && defaultSheet.getLastRow() === 0) {
    ss.deleteSheet(defaultSheet);
  }
  return true;
}

function getSheet(name) {
  var ss = getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    initializeDatabase();
    sheet = ss.getSheetByName(name);
  }
  return sheet;
}

/**
 * Google Sheets otomatis mengubah string tanggal/waktu yang kita tulis (mis. "2026-09-22")
 * menjadi sel bertipe Date. Saat dibaca ulang, nilainya jadi objek Date asli, bukan string.
 * Objek Date yang ikut terkirim ke client bisa membuat serialisasi google.script.run gagal
 * (client menerima null), jadi selalu diubah balik ke string yang konsisten.
 * Nilai yang hanya berisi JAM (mis. kolom "waktu" pada Kegiatan) disimpan Sheets dengan
 * tanggal dasar 30 Desember 1899 - kasus ini dideteksi lewat tahunnya dan hanya jamnya
 * ("HH:mm") yang diambil, tanggal bawaannya dibuang.
 */
function cellToValue_(cell) {
  if (Object.prototype.toString.call(cell) === '[object Date]') {
    var tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
    if (cell.getFullYear() === 1899) {
      return Utilities.formatDate(cell, tz, 'HH:mm');
    }
    var hasTime = cell.getHours() !== 0 || cell.getMinutes() !== 0 || cell.getSeconds() !== 0;
    return Utilities.formatDate(cell, tz, hasTime ? "yyyy-MM-dd'T'HH:mm:ss" : 'yyyy-MM-dd');
  }
  return cell;
}

/** Membaca seluruh baris sebuah sheet sekali panggil, dikembalikan sebagai array object. */
function sheetToObjects(sheetName) {
  var sheet = getSheet(sheetName);
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow < 2) return [];
  var values = sheet.getRange(1, 1, lastRow, lastCol).getValues();
  var headers = values[0];
  var result = [];
  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var isEmpty = row.every(function (c) { return c === '' || c === null; });
    if (isEmpty) continue;
    var obj = {};
    for (var c = 0; c < headers.length; c++) obj[headers[c]] = cellToValue_(row[c]);
    obj._row = i + 1;
    result.push(obj);
  }
  return result;
}

function objectToRowArray_(headers, obj) {
  return headers.map(function (h) {
    return obj.hasOwnProperty(h) && obj[h] !== undefined && obj[h] !== null ? obj[h] : '';
  });
}

function insertObjectUnlocked(sheetName, obj) {
  var sheet = getSheet(sheetName);
  var headers = SHEET_HEADERS[sheetName];
  sheet.appendRow(objectToRowArray_(headers, obj));
  return obj;
}

function insertObject(sheetName, obj) {
  return withLock(function () { return insertObjectUnlocked(sheetName, obj); });
}

function findObjectById(sheetName, id, idField) {
  idField = idField || 'id';
  var items = sheetToObjects(sheetName);
  for (var i = 0; i < items.length; i++) {
    if (String(items[i][idField]) === String(id)) return items[i];
  }
  return null;
}

function updateObjectByIdUnlocked(sheetName, id, updates, idField) {
  idField = idField || 'id';
  var sheet = getSheet(sheetName);
  var headers = SHEET_HEADERS[sheetName];
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) throw userError('Data tidak ditemukan.');
  var values = sheet.getRange(1, 1, lastRow, headers.length).getValues();
  var idCol = headers.indexOf(idField);
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === String(id)) {
      var merged = {};
      for (var c = 0; c < headers.length; c++) merged[headers[c]] = values[i][c];
      for (var key in updates) {
        if (headers.indexOf(key) !== -1) merged[key] = updates[key];
      }
      var newRow = objectToRowArray_(headers, merged);
      sheet.getRange(i + 1, 1, 1, headers.length).setValues([newRow]);
      return merged;
    }
  }
  throw userError('Data dengan ID ' + id + ' tidak ditemukan.');
}

function updateObjectById(sheetName, id, updates, idField) {
  return withLock(function () { return updateObjectByIdUnlocked(sheetName, id, updates, idField); });
}

function deleteObjectByIdUnlocked(sheetName, id, idField) {
  idField = idField || 'id';
  var sheet = getSheet(sheetName);
  var headers = SHEET_HEADERS[sheetName];
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) throw userError('Data tidak ditemukan.');
  var values = sheet.getRange(1, 1, lastRow, headers.length).getValues();
  var idCol = headers.indexOf(idField);
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === String(id)) {
      sheet.deleteRow(i + 1);
      return true;
    }
  }
  throw userError('Data dengan ID ' + id + ' tidak ditemukan.');
}

function deleteObjectById(sheetName, id, idField) {
  return withLock(function () { return deleteObjectByIdUnlocked(sheetName, id, idField); });
}

/** Penggenerate ID unik berformat PREFIX-000001, aman dari akses bersamaan. */
function generateIdUnlocked(prefix) {
  var sheet = getSheet(SHEET_NAMES.SETTINGS);
  var lastRow = sheet.getLastRow();
  var values = lastRow > 0 ? sheet.getRange(1, 1, lastRow, 2).getValues() : [];
  var key = 'counter_' + prefix;
  var rowIndex = -1, counterVal = 0;
  for (var i = 0; i < values.length; i++) {
    if (values[i][0] === key) { rowIndex = i + 1; counterVal = Number(values[i][1]) || 0; break; }
  }
  counterVal += 1;
  if (rowIndex === -1) {
    sheet.appendRow([key, counterVal, timestampNow()]);
  } else {
    sheet.getRange(rowIndex, 2, 1, 2).setValues([[counterVal, timestampNow()]]);
  }
  return prefix + '-' + ('000000' + counterVal).slice(-6);
}

function generateId(prefix) {
  return withLock(function () { return generateIdUnlocked(prefix); });
}

/** Membungkus operasi kritis dalam kunci skrip agar tidak bentrok antar pengguna. */
function withLock(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}
