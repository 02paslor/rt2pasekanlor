/**
 * Dashboard.gs
 * Mengagregasi seluruh statistik halaman utama dalam SATU pemanggilan agar
 * hemat kuota SpreadsheetApp (dibaca sekali per sheet, diproses di memori).
 */

function getDashboardData(token) {
  try {
    var session = requireAuth(token, 'dashboard', 1);
    var tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
    var thisMonth = todayString().substring(0, 7);
    var today = todayString();

    var warga = sheetToObjects(SHEET_NAMES.WARGA);
    var aktifWarga = warga.filter(function (w) { return w.status_warga !== 'Pindah' && w.status_warga !== 'Meninggal'; });
    var kkSet = {};
    aktifWarga.forEach(function (w) { kkSet[w.no_kk] = true; });
    var totalKK = Object.keys(kkSet).length;
    var totalWarga = aktifWarga.length;

    var jimpitan = sheetToObjects(SHEET_NAMES.JIMPITAN);
    var jimpitanBulanIni = jimpitan.filter(function (j) { return String(j.tanggal).substring(0, 7) === thisMonth; });
    var totalJimpitanBulanIni = 0;
    var setorSet = {};
    jimpitanBulanIni.forEach(function (j) {
      totalJimpitanBulanIni += Number(j.nominal) || 0;
      if (j.status === 'Lunas' || j.status === 'Sebagian') setorSet[j.no_kk] = true;
    });
    var totalRumahAktif = getActiveKepalaKeluarga_().length;
    var sudahSetor = Object.keys(setorSet).length;
    var belumSetor = Math.max(0, totalRumahAktif - sudahSetor);
    var persentaseSetor = totalRumahAktif > 0 ? Math.round((sudahSetor / totalRumahAktif) * 1000) / 10 : 0;

    var kas = sheetToObjects(SHEET_NAMES.KAS);
    var saldoAwal = Number(getSettingValue('saldo_awal_kas', 0)) || 0;
    var totalPemasukanAll = 0, totalPengeluaranAll = 0, pemasukanBulanIni = 0, pengeluaranBulanIni = 0;
    kas.forEach(function (k) {
      var nominal = Number(k.nominal) || 0;
      if (k.jenis === 'Pemasukan') {
        totalPemasukanAll += nominal;
        if (String(k.tanggal).substring(0, 7) === thisMonth) pemasukanBulanIni += nominal;
      } else {
        totalPengeluaranAll += nominal;
        if (String(k.tanggal).substring(0, 7) === thisMonth) pengeluaranBulanIni += nominal;
      }
    });
    var saldoKas = saldoAwal + totalPemasukanAll - totalPengeluaranAll;

    var chart = [];
    for (var i = 5; i >= 0; i--) {
      var d = new Date();
      d.setDate(1);
      d.setMonth(d.getMonth() - i);
      var key = Utilities.formatDate(d, tz, 'yyyy-MM');
      var label = Utilities.formatDate(d, tz, 'MMM yyyy');
      var pem = 0, peng = 0;
      kas.forEach(function (k) {
        if (String(k.tanggal).substring(0, 7) === key) {
          if (k.jenis === 'Pemasukan') pem += Number(k.nominal) || 0; else peng += Number(k.nominal) || 0;
        }
      });
      chart.push({ bulan: label, pemasukan: pem, pengeluaran: peng });
    }

    var logs = sheetToObjects(SHEET_NAMES.ACTIVITY_LOG);
    logs.sort(function (a, b) { return String(b.timestamp).localeCompare(String(a.timestamp)); });
    var aktivitas = logs.slice(0, 8).map(function (l) {
      return { user: l.user, action: l.action, module: l.module, description: l.description, timestamp: l.timestamp };
    });

    var kegiatan = sheetToObjects(SHEET_NAMES.KEGIATAN);
    var upcoming = kegiatan.filter(function (k) {
      return String(k.tanggal) >= today && (k.status === 'Rencana' || k.status === 'Berjalan');
    });
    upcoming.sort(function (a, b) { return String(a.tanggal).localeCompare(String(b.tanggal)); });
    var kegiatanTerdekat = upcoming.slice(0, 3).map(function (k) {
      return { id: k.id, nama_kegiatan: k.nama_kegiatan, tanggal: k.tanggal, waktu: k.waktu, lokasi: k.lokasi, status: k.status };
    });

    return successResponse({
      total_kk: totalKK, total_warga: totalWarga, jimpitan_bulan_ini: totalJimpitanBulanIni, saldo_kas: saldoKas,
      jimpitan_progress: { sudah: sudahSetor, belum: belumSetor, total_rumah: totalRumahAktif, persentase: persentaseSetor },
      keuangan: { pemasukan_bulan_ini: pemasukanBulanIni, pengeluaran_bulan_ini: pengeluaranBulanIni, saldo_bulan_ini: pemasukanBulanIni - pengeluaranBulanIni },
      chart_6_bulan: chart, aktivitas_terbaru: aktivitas, kegiatan_terdekat: kegiatanTerdekat,
      user: session
    });
  } catch (e) {
    return handleServerError(e, 'getDashboardData');
  }
}
