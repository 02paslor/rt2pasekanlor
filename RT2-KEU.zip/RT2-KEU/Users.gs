/**
 * Users.gs
 * Manajemen pengguna sistem (khusus ADMIN): tambah, ubah, aktif/nonaktifkan,
 * dan reset password. Password tidak pernah dikirim balik ke frontend.
 */

function sanitizeUser_(u) {
  return { id: u.id, username: u.username, nama: u.nama, role: u.role, status: u.status, last_login: u.last_login, created_at: u.created_at };
}

function getUserList(token) {
  try {
    requireAuth(token, 'users', 1);
    var users = sheetToObjects(SHEET_NAMES.USERS).map(sanitizeUser_);
    users.sort(function (a, b) { return String(a.nama).localeCompare(String(b.nama)); });
    return successResponse(users);
  } catch (e) {
    return handleServerError(e, 'getUserList');
  }
}

function addUser(token, data) {
  try {
    var session = requireAuth(token, 'users', 2);
    validateRequired(data, ['username', 'password', 'nama', 'role']);
    if (String(data.password).length < 6) throw userError('Password minimal 6 karakter.');
    if (Object.keys(ROLES).indexOf(data.role) === -1) throw userError('Role tidak valid.');

    var users = sheetToObjects(SHEET_NAMES.USERS);
    var exists = users.some(function (u) { return String(u.username).toLowerCase() === String(data.username).toLowerCase(); });
    if (exists) throw userError('Username sudah digunakan.');

    var id = withLock(function () {
      var newId = generateIdUnlocked(ID_PREFIX.USER);
      insertObjectUnlocked(SHEET_NAMES.USERS, {
        id: newId, username: data.username, password: createPasswordHash(data.password), nama: data.nama,
        role: data.role, status: 'Aktif', last_login: '', created_at: timestampNow(), updated_at: timestampNow()
      });
      return newId;
    });

    logActivity(session.username, 'Tambah User', 'Pengguna', session.nama + ' menambahkan pengguna ' + data.username + ' (' + data.role + ')');
    return successResponse({ id: id }, 'Pengguna berhasil ditambahkan.');
  } catch (e) {
    return handleServerError(e, 'addUser');
  }
}

function updateUser(token, id, data) {
  try {
    var session = requireAuth(token, 'users', 2);
    validateRequired(data, ['nama', 'role']);
    if (Object.keys(ROLES).indexOf(data.role) === -1) throw userError('Role tidak valid.');
    var existing = findObjectById(SHEET_NAMES.USERS, id);
    if (!existing) return errorResponse('Pengguna tidak ditemukan.');
    updateObjectById(SHEET_NAMES.USERS, id, { nama: data.nama, role: data.role, updated_at: timestampNow() });
    logActivity(session.username, 'Ubah User', 'Pengguna', session.nama + ' memperbarui data pengguna ' + existing.username);
    return successResponse({}, 'Data pengguna berhasil diperbarui.');
  } catch (e) {
    return handleServerError(e, 'updateUser');
  }
}

function toggleUserStatus(token, id) {
  try {
    var session = requireAuth(token, 'users', 2);
    var existing = findObjectById(SHEET_NAMES.USERS, id);
    if (!existing) return errorResponse('Pengguna tidak ditemukan.');
    if (String(existing.id) === String(session.id)) return errorResponse('Anda tidak dapat menonaktifkan akun sendiri.');
    var newStatus = existing.status === 'Aktif' ? 'Nonaktif' : 'Aktif';
    updateObjectById(SHEET_NAMES.USERS, id, { status: newStatus, updated_at: timestampNow() });
    logActivity(session.username, 'Ubah Status User', 'Pengguna', session.nama + ' mengubah status ' + existing.username + ' menjadi ' + newStatus);
    return successResponse({ status: newStatus }, 'Status pengguna berhasil diubah.');
  } catch (e) {
    return handleServerError(e, 'toggleUserStatus');
  }
}

function resetPassword(token, id, newPassword) {
  try {
    var session = requireAuth(token, 'users', 2);
    if (String(newPassword).length < 6) return errorResponse('Password baru minimal 6 karakter.');
    var existing = findObjectById(SHEET_NAMES.USERS, id);
    if (!existing) return errorResponse('Pengguna tidak ditemukan.');
    updateObjectById(SHEET_NAMES.USERS, id, { password: createPasswordHash(newPassword), updated_at: timestampNow() });
    logActivity(session.username, 'Reset Password', 'Pengguna', session.nama + ' mereset password pengguna ' + existing.username);
    return successResponse({}, 'Password pengguna berhasil direset.');
  } catch (e) {
    return handleServerError(e, 'resetPassword');
  }
}
