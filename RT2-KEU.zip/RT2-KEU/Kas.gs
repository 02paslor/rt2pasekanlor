/**
 * Kas.gs
 * Transaksi kas RT (pemasukan & pengeluaran) dan perhitungan saldo otomatis.
 * Saldo TIDAK disimpan manual - selalu dihitung dari saldo_awal_kas (Settings)
 * ditambah akumulasi seluruh transaksi di sheet KAS.
 */

function computeSaldoUpTo_(dateStrExclusive) {
  var saldoAwal = Number(getSettingValue('saldo_awal_kas', 0)) || 0;
  var items = sheetToObjects(SHEET_NAMES.KAS);
  var total = saldoAwal;
  items.forEach(function (k) {
    if (dateStrExclusive && String(k.tanggal) >= dateStrExclusive) return;
    var nominal = Number(k.nominal) || 0;
    total += (k.jenis === 'Pemasukan') ? nominal : -nominal;
  });
  return total;
}

function getSaldo(token) {
  try {
    requireAuth(token, 'kas', 1);
    var items = sheetToObjects(SHEET_NAMES.KAS);
    var saldoAwal = Number(getSettingValue('saldo_awal_kas', 0)) || 0;
    var totalPemasukan = 0, totalPengeluaran = 0;
    var thisMonth = todayString().substring(0, 7);
    var pemasukanBulanIni = 0, pengeluaranBulanIni = 0;
    items.forEach(function (k) {
      var nominal = Number(k.nominal) || 0;
      if (k.jenis === 'Pemasukan') {
        totalPemasukan += nominal;
        if (String(k.tanggal).substring(0, 7) === thisMonth) pemasukanBulanIni += nominal;
      } else {
        totalPengeluaran += nominal;
        if (String(k.tanggal).substring(0, 7) === thisMonth) pengeluaranBulanIni += nominal;
      }
    });
    var saldoAkhir = saldoAwal + totalPemasukan - totalPengeluaran;
    return successResponse({
      saldo: saldoAkhir, saldo_awal: saldoAwal, total_pemasukan: totalPemasukan, total_pengeluaran: totalPengeluaran,
      pemasukan_bulan_ini: pemasukanBulanIni, pengeluaran_bulan_ini: pengeluaranBulanIni,
      saldo_bulan_ini: pemasukanBulanIni - pengeluaranBulanIni
    });
  } catch (e) {
    return handleServerError(e, 'getSaldo');
  }
}

function addPemasukan(token, data) {
  try {
    var session = requireAuth(token, 'kas', 2);
    validateRequired(data, ['tanggal', 'kategori', 'nominal', 'sumber_tujuan']);
    if (!isValidDateStringValue(data.tanggal)) throw userError('Tanggal tidak valid.');
    if (!isValidNumberValue(data.nominal) || Number(data.nominal) <= 0) throw userError('Nominal harus berupa angka lebih dari 0.');

    var id = withLock(function () {
      var newId = generateIdUnlocked(ID_PREFIX.KAS);
      insertObjectUnlocked(SHEET_NAMES.KAS, {
        id: newId, tanggal: data.tanggal, jenis: 'Pemasukan', kategori: data.kategori,
        nominal: Number(data.nominal), sumber_tujuan: data.sumber_tujuan, keterangan: data.keterangan || '',
        bukti: data.bukti || '', kegiatan_id: data.kegiatan_id || '', created_by: session.nama, created_at: timestampNow()
      });
      return newId;
    });

    logActivity(session.username, 'Tambah Pemasukan', 'Kas', session.nama + ' mencatat pemasukan Rp' + Number(data.nominal).toLocaleString('id-ID') + ' (' + data.kategori + ')');
    return successResponse({ id: id }, 'Pemasukan berhasil dicatat.');
  } catch (e) {
    return handleServerError(e, 'addPemasukan');
  }
}

function addPengeluaran(token, data) {
  try {
    var session = requireAuth(token, 'kas', 2);
    validateRequired(data, ['tanggal', 'kategori', 'nominal', 'sumber_tujuan']);
    if (!isValidDateStringValue(data.tanggal)) throw userError('Tanggal tidak valid.');
    if (!isValidNumberValue(data.nominal) || Number(data.nominal) <= 0) throw userError('Nominal harus berupa angka lebih dari 0.');

    var id = withLock(function () {
      var newId = generateIdUnlocked(ID_PREFIX.KAS);
      insertObjectUnlocked(SHEET_NAMES.KAS, {
        id: newId, tanggal: data.tanggal, jenis: 'Pengeluaran', kategori: data.kategori,
        nominal: Number(data.nominal), sumber_tujuan: data.sumber_tujuan, keterangan: data.keterangan || '',
        bukti: data.bukti || '', kegiatan_id: data.kegiatan_id || '', created_by: session.nama, created_at: timestampNow()
      });
      return newId;
    });

    logActivity(session.username, 'Tambah Pengeluaran', 'Kas', session.nama + ' mencatat pengeluaran Rp' + Number(data.nominal).toLocaleString('id-ID') + ' (' + data.kategori + ')');
    return successResponse({ id: id }, 'Pengeluaran berhasil dicatat.');
  } catch (e) {
    return handleServerError(e, 'addPengeluaran');
  }
}

function getKasList(token, opts) {
  try {
    requireAuth(token, 'kas', 1);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.KAS);
    items = items.filter(function (k) {
      if (opts.jenis && k.jenis !== opts.jenis) return false;
      if (opts.kategori && k.kategori !== opts.kategori) return false;
      if (opts.bulan && String(k.tanggal).substring(0, 7) !== opts.bulan) return false;
      if (opts.tahun && String(k.tanggal).substring(0, 4) !== String(opts.tahun)) return false;
      if (opts.search && !(textMatches(k.sumber_tujuan, opts.search) || textMatches(k.keterangan, opts.search))) return false;
      return true;
    });
    items.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });
    var mapped = items.map(function (k) {
      return {
        id: k.id, tanggal: k.tanggal, jenis: k.jenis, kategori: k.kategori, nominal: Number(k.nominal) || 0,
        sumber_tujuan: k.sumber_tujuan, keterangan: k.keterangan, bukti: k.bukti, kegiatan_id: k.kegiatan_id, created_by: k.created_by
      };
    });
    var result = paginateArray(mapped, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getKasList');
  }
}

function updateKas(token, id, data) {
  try {
    var session = requireAuth(token, 'kas', 2);
    validateRequired(data, ['tanggal', 'kategori', 'nominal', 'sumber_tujuan']);
    if (!isValidNumberValue(data.nominal) || Number(data.nominal) <= 0) throw userError('Nominal harus berupa angka lebih dari 0.');
    var existing = findObjectById(SHEET_NAMES.KAS, id);
    if (!existing) return errorResponse('Data transaksi tidak ditemukan.');
    var updates = {
      tanggal: data.tanggal, kategori: data.kategori, nominal: Number(data.nominal),
      sumber_tujuan: data.sumber_tujuan, keterangan: data.keterangan || '', bukti: data.bukti || ''
    };
    if (data.kegiatan_id !== undefined) updates.kegiatan_id = data.kegiatan_id;
    updateObjectById(SHEET_NAMES.KAS, id, updates);
    logActivity(session.username, 'Ubah', 'Kas', session.nama + ' mengubah transaksi kas ' + existing.jenis + ' Rp' + Number(data.nominal).toLocaleString('id-ID'));
    return successResponse({}, 'Transaksi berhasil diperbarui.');
  } catch (e) {
    return handleServerError(e, 'updateKas');
  }
}

function deleteKas(token, id) {
  try {
    var session = requireAuth(token, 'kas', 2);
    var existing = findObjectById(SHEET_NAMES.KAS, id);
    if (!existing) return errorResponse('Data transaksi tidak ditemukan.');
    deleteObjectById(SHEET_NAMES.KAS, id);
    logActivity(session.username, 'Hapus', 'Kas', session.nama + ' menghapus transaksi kas ' + existing.jenis + ' Rp' + Number(existing.nominal).toLocaleString('id-ID'));
    return successResponse({}, 'Transaksi berhasil dihapus.');
  } catch (e) {
    return handleServerError(e, 'deleteKas');
  }
}

function getLaporanKeuangan(token, opts) {
  try {
    requireAuth(token, 'laporan', 2);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.KAS);
    var start = null, end = null;
    if (opts.bulan) {
      start = opts.bulan + '-01';
      var parts = opts.bulan.split('-');
      var lastDate = new Date(Number(parts[0]), Number(parts[1]), 0);
      end = opts.bulan + '-' + ('0' + lastDate.getDate()).slice(-2);
    } else if (opts.tahun) {
      start = opts.tahun + '-01-01';
      end = opts.tahun + '-12-31';
    }

    var saldoAwal = computeSaldoUpTo_(start);
    var periodItems = items.filter(function (k) {
      if (start && String(k.tanggal) < start) return false;
      if (end && String(k.tanggal) > end) return false;
      return true;
    });
    var totalPemasukan = 0, totalPengeluaran = 0;
    periodItems.forEach(function (k) {
      var nominal = Number(k.nominal) || 0;
      if (k.jenis === 'Pemasukan') totalPemasukan += nominal; else totalPengeluaran += nominal;
    });
    var saldoAkhir = saldoAwal + totalPemasukan - totalPengeluaran;

    var tableItems = periodItems.filter(function (k) {
      if (opts.jenis && k.jenis !== opts.jenis) return false;
      if (opts.kategori && k.kategori !== opts.kategori) return false;
      return true;
    }).map(function (k) {
      return {
        id: k.id, tanggal: k.tanggal, jenis: k.jenis, kategori: k.kategori, nominal: Number(k.nominal) || 0,
        sumber_tujuan: k.sumber_tujuan, keterangan: k.keterangan, created_by: k.created_by
      };
    });
    tableItems.sort(function (a, b) { return String(a.tanggal).localeCompare(String(b.tanggal)); });

    return successResponse({
      periode_awal: start, periode_akhir: end, saldo_awal: saldoAwal, total_pemasukan: totalPemasukan,
      total_pengeluaran: totalPengeluaran, saldo_akhir: saldoAkhir, transaksi: tableItems
    });
  } catch (e) {
    return handleServerError(e, 'getLaporanKeuangan');
  }
}

/** Total pengeluaran kas yang terhubung ke sebuah kegiatan (dipakai Kegiatan.gs). */
function getKasTotalByKegiatan_(kegiatanId) {
  var items = sheetToObjects(SHEET_NAMES.KAS).filter(function (k) {
    return k.kegiatan_id === kegiatanId && k.jenis === 'Pengeluaran';
  });
  var total = 0;
  items.forEach(function (k) { total += Number(k.nominal) || 0; });
  return {
    total: total,
    transaksi: items.map(function (k) { return { id: k.id, tanggal: k.tanggal, nominal: Number(k.nominal) || 0, keterangan: k.keterangan }; })
  };
}
