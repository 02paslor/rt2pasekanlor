/**
 * Kegiatan.gs
 * CRUD kegiatan RT, termasuk ringkasan pengeluaran kas yang terhubung
 * ke sebuah kegiatan pada halaman detail.
 */

var KEGIATAN_REQUIRED_FIELDS = ['nama_kegiatan', 'tanggal', 'lokasi', 'penanggung_jawab', 'status'];

function getKegiatanList(token, opts) {
  try {
    requireAuth(token, 'kegiatan', 1);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.KEGIATAN);
    items = items.filter(function (k) {
      if (opts.search && !textMatches(k.nama_kegiatan, opts.search)) return false;
      if (opts.status && k.status !== opts.status) return false;
      return true;
    });
    items.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });
    var mapped = items.map(function (k) {
      return {
        id: k.id, nama_kegiatan: k.nama_kegiatan, tanggal: k.tanggal, waktu: k.waktu,
        lokasi: k.lokasi, penanggung_jawab: k.penanggung_jawab, anggaran: Number(k.anggaran) || 0, status: k.status
      };
    });
    var result = paginateArray(mapped, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getKegiatanList');
  }
}

function getKegiatanDetail(token, id) {
  try {
    requireAuth(token, 'kegiatan', 1);
    var k = findObjectById(SHEET_NAMES.KEGIATAN, id);
    if (!k) return errorResponse('Kegiatan tidak ditemukan.');
    var pengeluaran = getKasTotalByKegiatan_(id);
    var detail = {};
    for (var key in k) detail[key] = k[key];
    detail.anggaran = Number(k.anggaran) || 0;
    detail.pengeluaran_total = pengeluaran.total;
    detail.pengeluaran_transaksi = pengeluaran.transaksi;
    return successResponse(detail);
  } catch (e) {
    return handleServerError(e, 'getKegiatanDetail');
  }
}

function addKegiatan(token, data) {
  try {
    var session = requireAuth(token, 'kegiatan', 2);
    validateRequired(data, KEGIATAN_REQUIRED_FIELDS);
    if (!isValidDateStringValue(data.tanggal)) throw userError('Tanggal kegiatan tidak valid.');
    if (data.anggaran && !isValidNumberValue(data.anggaran)) throw userError('Anggaran harus berupa angka.');

    var id = withLock(function () {
      var newId = generateIdUnlocked(ID_PREFIX.KEGIATAN);
      insertObjectUnlocked(SHEET_NAMES.KEGIATAN, {
        id: newId, nama_kegiatan: data.nama_kegiatan, tanggal: data.tanggal, waktu: data.waktu || '',
        lokasi: data.lokasi, penanggung_jawab: data.penanggung_jawab, anggaran: Number(data.anggaran) || 0,
        status: data.status, deskripsi: data.deskripsi || '', created_at: timestampNow(), updated_at: timestampNow()
      });
      return newId;
    });

    logActivity(session.username, 'Tambah', 'Kegiatan', session.nama + ' menambahkan kegiatan ' + data.nama_kegiatan);
    return successResponse({ id: id }, 'Kegiatan berhasil disimpan.');
  } catch (e) {
    return handleServerError(e, 'addKegiatan');
  }
}

function updateKegiatan(token, id, data) {
  try {
    var session = requireAuth(token, 'kegiatan', 2);
    validateRequired(data, KEGIATAN_REQUIRED_FIELDS);
    var existing = findObjectById(SHEET_NAMES.KEGIATAN, id);
    if (!existing) return errorResponse('Kegiatan tidak ditemukan.');
    updateObjectById(SHEET_NAMES.KEGIATAN, id, {
      nama_kegiatan: data.nama_kegiatan, tanggal: data.tanggal, waktu: data.waktu || '', lokasi: data.lokasi,
      penanggung_jawab: data.penanggung_jawab, anggaran: Number(data.anggaran) || 0, status: data.status,
      deskripsi: data.deskripsi || '', updated_at: timestampNow()
    });
    logActivity(session.username, 'Ubah', 'Kegiatan', session.nama + ' memperbarui kegiatan ' + data.nama_kegiatan);
    return successResponse({}, 'Kegiatan berhasil diperbarui.');
  } catch (e) {
    return handleServerError(e, 'updateKegiatan');
  }
}

function deleteKegiatan(token, id) {
  try {
    var session = requireAuth(token, 'kegiatan', 2);
    var existing = findObjectById(SHEET_NAMES.KEGIATAN, id);
    if (!existing) return errorResponse('Kegiatan tidak ditemukan.');
    deleteObjectById(SHEET_NAMES.KEGIATAN, id);
    logActivity(session.username, 'Hapus', 'Kegiatan', session.nama + ' menghapus kegiatan ' + existing.nama_kegiatan);
    return successResponse({}, 'Kegiatan berhasil dihapus.');
  } catch (e) {
    return handleServerError(e, 'deleteKegiatan');
  }
}
