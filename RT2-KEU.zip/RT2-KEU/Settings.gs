/**
 * Settings.gs
 * Pengaturan RT tersimpan sebagai key-value di sheet SETTINGS.
 * Kunci internal (counter_*) disembunyikan dari UI Pengaturan.
 */

function upsertSettingUnlocked(key, value) {
  var sheet = getSheet(SHEET_NAMES.SETTINGS);
  var lastRow = sheet.getLastRow();
  var values = lastRow > 0 ? sheet.getRange(1, 1, lastRow, 1).getValues() : [];
  for (var i = 0; i < values.length; i++) {
    if (values[i][0] === key) {
      sheet.getRange(i + 1, 2, 1, 2).setValues([[value, timestampNow()]]);
      return;
    }
  }
  sheet.appendRow([key, value, timestampNow()]);
}

function upsertSetting(key, value) {
  return withLock(function () { return upsertSettingUnlocked(key, value); });
}

/** Peta lengkap semua setting (termasuk counter internal) - dipakai internal server saja. */
function getSettingsMap() {
  var rows = sheetToObjects(SHEET_NAMES.SETTINGS);
  var map = {};
  rows.forEach(function (r) { map[r.key] = r.value; });
  return map;
}

function getSettingValue(key, defaultValue) {
  var map = getSettingsMap();
  return map.hasOwnProperty(key) && map[key] !== '' ? map[key] : defaultValue;
}

/** Setting yang ditampilkan/diedit di halaman Pengaturan RT (menyembunyikan counter internal & log). */
function getSettings(token) {
  try {
    requireAuth(token, 'settings', 1);
    var map = getSettingsMap();
    var result = {};
    DEFAULT_SETTINGS_KEYS.forEach(function (key) {
      result[key] = map.hasOwnProperty(key) ? map[key] : '';
    });
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getSettings');
  }
}

function updateSettings(token, settingsObj) {
  try {
    var session = requireAuth(token, 'settings', 2);
    withLock(function () {
      DEFAULT_SETTINGS_KEYS.forEach(function (key) {
        if (settingsObj.hasOwnProperty(key)) {
          upsertSettingUnlocked(key, settingsObj[key]);
        }
      });
    });
    logActivity(session.username, 'Ubah Pengaturan', 'Pengaturan', session.nama + ' memperbarui pengaturan RT');
    return successResponse({}, 'Pengaturan berhasil disimpan.');
  } catch (e) {
    return handleServerError(e, 'updateSettings');
  }
}
