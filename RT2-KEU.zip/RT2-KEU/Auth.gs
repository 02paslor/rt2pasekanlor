/**
 * Auth.gs
 * Autentikasi, sesi (CacheService), setup awal aplikasi, dan validasi hak akses.
 * Semua fungsi modul lain memvalidasi akses lewat requireAuth() di sini -
 * frontend tidak pernah dipercaya untuk menentukan role.
 */

function checkSetupStatus() {
  try {
    return successResponse({ done: isSetupComplete() });
  } catch (e) {
    return handleServerError(e, 'checkSetupStatus');
  }
}

/**
 * Dijalankan sekali di awal: membuat seluruh sheet, mengisi SETTINGS,
 * dan membuat akun ADMIN pertama sesuai isian form setup.
 */
function completeSetup(payload) {
  try {
    if (isSetupComplete()) return errorResponse('Aplikasi sudah pernah disetup.');
    validateRequired(payload, ['rt_name', 'desa', 'kecamatan', 'kabupaten', 'provinsi',
      'admin_username', 'admin_password', 'admin_nama']);
    if (String(payload.admin_password).length < 6) {
      return errorResponse('Password admin minimal 6 karakter.');
    }

    initializeDatabase();

    var settingsMap = {
      rt_name: payload.rt_name,
      rw_name: payload.rw_name || '',
      dusun: payload.dusun || '',
      desa: payload.desa,
      kecamatan: payload.kecamatan,
      kabupaten: payload.kabupaten,
      provinsi: payload.provinsi,
      jimpitan_nominal: payload.jimpitan_nominal || 1000,
      nama_ketua: payload.nama_ketua || '',
      nama_bendahara: payload.nama_bendahara || '',
      nama_sekretaris: payload.nama_sekretaris || '',
      saldo_awal_kas: payload.saldo_awal_kas || 0
    };

    withLock(function () {
      Object.keys(settingsMap).forEach(function (key) {
        upsertSettingUnlocked(key, settingsMap[key]);
      });
      var id = generateIdUnlocked(ID_PREFIX.USER);
      insertObjectUnlocked(SHEET_NAMES.USERS, {
        id: id,
        username: payload.admin_username,
        password: createPasswordHash(payload.admin_password),
        nama: payload.admin_nama,
        role: ROLES.ADMIN,
        status: 'Aktif',
        last_login: '',
        created_at: timestampNow(),
        updated_at: timestampNow()
      });
    });

    markSetupComplete();
    logActivity(payload.admin_username, 'Setup', 'Sistem', 'Setup awal aplikasi RT 05 Kwarasan selesai dilakukan');
    return successResponse({}, 'Setup berhasil. Silakan login dengan akun Admin yang baru dibuat.');
  } catch (e) {
    return handleServerError(e, 'completeSetup');
  }
}

function login(username, password) {
  try {
    if (!username || !password) return errorResponse('Username dan password wajib diisi.');
    var users = sheetToObjects(SHEET_NAMES.USERS);
    var user = null;
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].username).toLowerCase() === String(username).toLowerCase().trim()) {
        user = users[i];
        break;
      }
    }
    if (!user) return errorResponse('Username atau password salah.');
    if (user.status !== 'Aktif') return errorResponse('Akun Anda tidak aktif. Silakan hubungi Admin RT.');
    if (!verifyPasswordHash(password, user.password)) return errorResponse('Username atau password salah.');

    var token = Utilities.getUuid();
    var sessionData = { id: user.id, username: user.username, nama: user.nama, role: user.role };
    CacheService.getScriptCache().put('session_' + token, JSON.stringify(sessionData), SESSION_DURATION_SECONDS);

    updateObjectById(SHEET_NAMES.USERS, user.id, { last_login: timestampNow() });
    logActivity(user.username, 'Login', 'Auth', user.nama + ' berhasil login ke sistem');

    return successResponse({ token: token, user: sessionData });
  } catch (e) {
    return handleServerError(e, 'login');
  }
}

function logout(token) {
  try {
    var session = getSession(token);
    CacheService.getScriptCache().remove('session_' + token);
    if (session) logActivity(session.username, 'Logout', 'Auth', session.nama + ' logout dari sistem');
    return successResponse({});
  } catch (e) {
    return handleServerError(e, 'logout');
  }
}

function validateSession(token) {
  var session = getSession(token);
  if (!session) return errorResponse('Sesi tidak valid atau sudah kedaluwarsa.');
  return successResponse({ user: session });
}

function getSession(token) {
  if (!token) return null;
  var cache = CacheService.getScriptCache();
  var raw = cache.get('session_' + token);
  if (!raw) return null;
  try {
    var session = JSON.parse(raw);
    cache.put('session_' + token, raw, SESSION_DURATION_SECONDS);
    return session;
  } catch (e) {
    return null;
  }
}

/**
 * Dipanggil di awal setiap fungsi server yang butuh proteksi.
 * module & minLevel opsional - jika diisi, memvalidasi hak akses modul juga.
 */
function requireAuth(token, module, minLevel) {
  var session = getSession(token);
  if (!session) throw new Error('AUTH_REQUIRED');
  if (module) {
    var perms = ROLE_PERMISSIONS[session.role] || {};
    var level = perms[module] || 0;
    if (level < (minLevel || 1)) throw new Error('AUTH_FORBIDDEN');
  }
  return session;
}

function changePassword(token, oldPassword, newPassword) {
  try {
    var session = requireAuth(token);
    var user = findObjectById(SHEET_NAMES.USERS, session.id);
    if (!user) return errorResponse('User tidak ditemukan.');
    if (!verifyPasswordHash(oldPassword, user.password)) return errorResponse('Password lama salah.');
    if (String(newPassword).length < 6) return errorResponse('Password baru minimal 6 karakter.');
    updateObjectById(SHEET_NAMES.USERS, user.id, { password: createPasswordHash(newPassword) });
    logActivity(session.username, 'Ubah Password', 'Auth', session.nama + ' mengubah password akun sendiri');
    return successResponse({}, 'Password berhasil diubah.');
  } catch (e) {
    return handleServerError(e, 'changePassword');
  }
}
