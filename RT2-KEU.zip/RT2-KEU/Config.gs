/**
 * Config.gs
 * Konfigurasi global aplikasi RT 05 Kwarasan.
 * Menyimpan nama aplikasi, definisi sheet, role & permission, serta
 * pengaturan koneksi ke Google Spreadsheet yang dipakai sebagai database.
 */

var APP_NAME = 'RT 05 Kwarasan';
var APP_SUBTITLE = 'Nogotirto, Gamping, Sleman';
var APP_FOOTER = '© ' + new Date().getFullYear() + ' RT 05 Kwarasan - Nogotirto, Gamping, Sleman';

var SHEET_NAMES = {
  USERS: 'USERS',
  WARGA: 'WARGA',
  MUTASI_WARGA: 'MUTASI_WARGA',
  JIMPITAN: 'JIMPITAN',
  KAS: 'KAS',
  KEGIATAN: 'KEGIATAN',
  SETTINGS: 'SETTINGS',
  ACTIVITY_LOG: 'ACTIVITY_LOG'
};

var SHEET_HEADERS = {
  USERS: ['id', 'username', 'password', 'nama', 'role', 'status', 'last_login', 'created_at', 'updated_at'],
  WARGA: ['id', 'no_kk', 'nik', 'nama_lengkap', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir',
    'status_perkawinan', 'agama', 'pendidikan', 'pekerjaan', 'status_dalam_keluarga', 'no_hp',
    'alamat', 'rt', 'rw', 'status_warga', 'tanggal_masuk', 'tanggal_keluar', 'keterangan',
    'created_at', 'updated_at'],
  MUTASI_WARGA: ['id', 'warga_id', 'jenis_mutasi', 'tanggal', 'alasan', 'tujuan', 'keterangan',
    'created_by', 'created_at'],
  JIMPITAN: ['id', 'tanggal', 'warga_id', 'no_kk', 'nama_kepala_keluarga', 'nominal', 'metode',
    'status', 'petugas', 'keterangan', 'created_at', 'updated_at'],
  KAS: ['id', 'tanggal', 'jenis', 'kategori', 'nominal', 'sumber_tujuan', 'keterangan', 'bukti',
    'kegiatan_id', 'created_by', 'created_at'],
  KEGIATAN: ['id', 'nama_kegiatan', 'tanggal', 'waktu', 'lokasi', 'penanggung_jawab', 'anggaran',
    'status', 'deskripsi', 'created_at', 'updated_at'],
  SETTINGS: ['key', 'value', 'updated_at'],
  ACTIVITY_LOG: ['id', 'user', 'action', 'module', 'description', 'timestamp']
};

var ROLES = {
  ADMIN: 'ADMIN',
  BENDAHARA: 'BENDAHARA',
  PENGURUS: 'PENGURUS',
  VIEWER: 'VIEWER'
};

/**
 * Peta hak akses per modul.
 * 2 = akses penuh (tambah/ubah/hapus), 1 = lihat saja, tidak ada key = tidak ada akses.
 * Ini adalah sumber kebenaran di server; frontend hanya menyesuaikan tampilan.
 */
var ROLE_PERMISSIONS = {
  ADMIN: { dashboard: 2, warga: 2, jimpitan: 2, kas: 2, kegiatan: 2, laporan: 2, settings: 2, users: 2 },
  BENDAHARA: { dashboard: 1, jimpitan: 2, kas: 2, laporan: 2 },
  PENGURUS: { dashboard: 1, warga: 2, jimpitan: 2, kegiatan: 2, laporan: 2 },
  VIEWER: { dashboard: 1, warga: 1, kegiatan: 1, laporan: 1 }
};

var ID_PREFIX = {
  WARGA: 'WGN',
  JIMPITAN: 'JMP',
  KAS: 'KAS',
  KEGIATAN: 'KTG',
  MUTASI: 'MUT',
  USER: 'USR',
  LOG: 'LOG'
};

var SESSION_DURATION_SECONDS = 6 * 60 * 60; // 6 jam

var DEFAULT_SETTINGS_KEYS = [
  'rt_name', 'rw_name', 'dusun', 'desa', 'kecamatan', 'kabupaten', 'provinsi',
  'jimpitan_nominal', 'nama_ketua', 'nama_bendahara', 'nama_sekretaris', 'saldo_awal_kas'
];

/**
 * Mengambil (atau membuat jika belum ada) ID Spreadsheet database.
 * Disimpan di Script Properties agar tidak perlu dikonfigurasi manual di kode.
 */
function getSpreadsheetId() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SPREADSHEET_ID');
  if (!id) {
    var ss = SpreadsheetApp.create(APP_NAME + ' - Database');
    id = ss.getId();
    props.setProperty('SPREADSHEET_ID', id);
  }
  return id;
}

function getActiveSpreadsheet() {
  return SpreadsheetApp.openById(getSpreadsheetId());
}

function isSetupComplete() {
  return PropertiesService.getScriptProperties().getProperty('SETUP_DONE') === 'true';
}

function markSetupComplete() {
  PropertiesService.getScriptProperties().setProperty('SETUP_DONE', 'true');
}
