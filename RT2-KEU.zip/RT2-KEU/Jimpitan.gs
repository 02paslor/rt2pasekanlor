/**
 * Jimpitan.gs
 * Sistem jimpitan: input cepat harian, rekap (hari/minggu/bulan/tahun),
 * riwayat, dan rekap bulanan lengkap dengan grafik.
 * Satu baris JIMPITAN merepresentasikan satu rumah (no_kk) pada satu tanggal.
 */

function getActiveKepalaKeluarga_() {
  var warga = sheetToObjects(SHEET_NAMES.WARGA);
  var kepalaByKK = {};
  warga.forEach(function (w) {
    if (w.status_warga === 'Pindah' || w.status_warga === 'Meninggal') return;
    if (!kepalaByKK[w.no_kk]) kepalaByKK[w.no_kk] = w;
    if (w.status_dalam_keluarga === 'Kepala Keluarga') kepalaByKK[w.no_kk] = w;
  });
  return Object.keys(kepalaByKK).sort().map(function (kk) {
    var w = kepalaByKK[kk];
    return { no_kk: kk, warga_id: w.id, nama: w.nama_lengkap };
  });
}

function getWeekRange_(dateStr) {
  var d = new Date(dateStr + 'T00:00:00');
  var day = d.getDay();
  var diffToMonday = day === 0 ? -6 : 1 - day;
  var monday = new Date(d); monday.setDate(d.getDate() + diffToMonday);
  var sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
  var tz = Session.getScriptTimeZone() || 'Asia/Jakarta';
  return {
    start: Utilities.formatDate(monday, tz, 'yyyy-MM-dd'),
    end: Utilities.formatDate(sunday, tz, 'yyyy-MM-dd')
  };
}

/** Daftar rumah untuk halaman Input Jimpitan Cepat pada tanggal tertentu. */
function getRumahListForInput(token, tanggal) {
  try {
    requireAuth(token, 'jimpitan', 1);
    if (!tanggal) tanggal = todayString();
    var activeKK = getActiveKepalaKeluarga_();
    var existing = sheetToObjects(SHEET_NAMES.JIMPITAN).filter(function (j) { return String(j.tanggal) === tanggal; });
    var existingMap = {};
    existing.forEach(function (j) { existingMap[j.no_kk] = j; });
    var defaultNominal = Number(getSettingValue('jimpitan_nominal', 1000)) || 1000;

    var list = activeKK.map(function (kk, idx) {
      var e = existingMap[kk.no_kk];
      return {
        no: idx + 1, no_kk: kk.no_kk, warga_id: kk.warga_id, nama_kepala_keluarga: kk.nama,
        nominal: e ? Number(e.nominal) : defaultNominal, metode: e ? e.metode : 'Tunai',
        status: e ? e.status : 'Belum Bayar', keterangan: e ? e.keterangan : ''
      };
    });
    return successResponse({ tanggal: tanggal, default_nominal: defaultNominal, list: list });
  } catch (e) {
    return handleServerError(e, 'getRumahListForInput');
  }
}

/** Menyimpan satu batch pencatatan jimpitan (upsert per rumah per tanggal) sekali kunci. */
function saveJimpitanBatch(token, tanggal, petugas, entries) {
  try {
    var session = requireAuth(token, 'jimpitan', 2);
    if (!isValidDateStringValue(tanggal)) throw userError('Tanggal tidak valid.');
    if (!entries || entries.length === 0) throw userError('Tidak ada data untuk disimpan.');

    var savedCount = withLock(function () {
      var sheet = getSheet(SHEET_NAMES.JIMPITAN);
      var headers = SHEET_HEADERS.JIMPITAN;
      var lastRow = sheet.getLastRow();
      var values = lastRow > 0 ? sheet.getRange(1, 1, lastRow, headers.length).getValues() : [headers];
      var tglCol = headers.indexOf('tanggal');
      var kkCol = headers.indexOf('no_kk');
      var idCol = headers.indexOf('id');
      var createdCol = headers.indexOf('created_at');

      var existingRowIndex = {};
      for (var i = 1; i < values.length; i++) {
        existingRowIndex[values[i][tglCol] + '|' + values[i][kkCol]] = i + 1;
      }

      var newRows = [];
      var count = 0;
      entries.forEach(function (entry) {
        if (!entry.no_kk) return;
        var nominal = Number(entry.nominal) || 0;
        var status = entry.status || (nominal > 0 ? 'Lunas' : 'Belum Bayar');
        var key = tanggal + '|' + entry.no_kk;
        var rowObj = {
          id: '', tanggal: tanggal, warga_id: entry.warga_id || '', no_kk: entry.no_kk,
          nama_kepala_keluarga: entry.nama_kepala_keluarga || '', nominal: nominal,
          metode: entry.metode || 'Tunai', status: status, petugas: petugas || session.nama,
          keterangan: entry.keterangan || '', created_at: timestampNow(), updated_at: timestampNow()
        };
        if (existingRowIndex[key]) {
          var rowNum = existingRowIndex[key];
          rowObj.id = values[rowNum - 1][idCol];
          rowObj.created_at = values[rowNum - 1][createdCol];
          sheet.getRange(rowNum, 1, 1, headers.length).setValues([objectToRowArray_(headers, rowObj)]);
        } else {
          rowObj.id = generateIdUnlocked(ID_PREFIX.JIMPITAN);
          newRows.push(objectToRowArray_(headers, rowObj));
        }
        count++;
      });

      if (newRows.length > 0) {
        sheet.getRange(sheet.getLastRow() + 1, 1, newRows.length, headers.length).setValues(newRows);
      }
      return count;
    });

    logActivity(session.username, 'Catat Jimpitan', 'Jimpitan', session.nama + ' mencatat jimpitan tanggal ' + tanggal + ' (' + savedCount + ' rumah)');
    return successResponse({ count: savedCount }, 'Jimpitan berhasil disimpan untuk ' + savedCount + ' rumah.');
  } catch (e) {
    return handleServerError(e, 'saveJimpitanBatch');
  }
}

function getJimpitanRekap(token, opts) {
  try {
    requireAuth(token, 'jimpitan', 1);
    opts = opts || {};
    var periode = opts.periode || 'hari';
    var items = sheetToObjects(SHEET_NAMES.JIMPITAN);

    items = items.filter(function (j) {
      var tgl = String(j.tanggal);
      if (periode === 'hari') {
        if (!opts.tanggal || tgl !== opts.tanggal) return false;
      } else if (periode === 'minggu') {
        if (!opts.tanggal) return false;
        var range = getWeekRange_(opts.tanggal);
        if (tgl < range.start || tgl > range.end) return false;
      } else if (periode === 'bulan') {
        if (!opts.bulan || tgl.substring(0, 7) !== opts.bulan) return false;
      } else if (periode === 'tahun') {
        if (!opts.tahun || tgl.substring(0, 4) !== String(opts.tahun)) return false;
      }
      if (opts.no_kk && j.no_kk !== opts.no_kk) return false;
      return true;
    });

    var totalAktifKK = getActiveKepalaKeluarga_().length;
    var totalNominal = 0;
    var setorKKSet = {};
    items.forEach(function (j) {
      totalNominal += Number(j.nominal) || 0;
      if (j.status === 'Lunas' || j.status === 'Sebagian') setorKKSet[j.no_kk] = true;
    });
    var sudahSetor = Object.keys(setorKKSet).length;
    var belum = Math.max(0, totalAktifKK - sudahSetor);
    var persentase = totalAktifKK > 0 ? Math.round((sudahSetor / totalAktifKK) * 1000) / 10 : 0;
    var rataRata = items.length > 0 ? Math.round(totalNominal / items.length) : 0;

    var list = items.map(function (j) {
      return {
        id: j.id, tanggal: j.tanggal, no_kk: j.no_kk, nama_kepala_keluarga: j.nama_kepala_keluarga,
        nominal: Number(j.nominal) || 0, status: j.status, metode: j.metode, petugas: j.petugas
      };
    });
    list.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });

    return successResponse({
      total_nominal: totalNominal, total_transaksi: items.length, rumah_sudah_setor: sudahSetor,
      rumah_belum_setor: belum, total_rumah_aktif: totalAktifKK, persentase: persentase,
      rata_rata: rataRata, list: list
    });
  } catch (e) {
    return handleServerError(e, 'getJimpitanRekap');
  }
}

function getJimpitanRiwayat(token, opts) {
  try {
    requireAuth(token, 'jimpitan', 1);
    opts = opts || {};
    var items = sheetToObjects(SHEET_NAMES.JIMPITAN);
    items = items.filter(function (j) {
      if (opts.search && !(textMatches(j.nama_kepala_keluarga, opts.search) || textMatches(j.no_kk, opts.search))) return false;
      if (opts.status && j.status !== opts.status) return false;
      if (opts.tanggal_dari && String(j.tanggal) < opts.tanggal_dari) return false;
      if (opts.tanggal_sampai && String(j.tanggal) > opts.tanggal_sampai) return false;
      return true;
    });
    items.sort(function (a, b) { return String(b.tanggal).localeCompare(String(a.tanggal)); });
    var mapped = items.map(function (j) {
      return {
        id: j.id, tanggal: j.tanggal, no_kk: j.no_kk, nama_kepala_keluarga: j.nama_kepala_keluarga,
        nominal: Number(j.nominal) || 0, metode: j.metode, status: j.status, petugas: j.petugas, keterangan: j.keterangan
      };
    });
    var result = paginateArray(mapped, opts.page, opts.pageSize);
    return successResponse(result);
  } catch (e) {
    return handleServerError(e, 'getJimpitanRiwayat');
  }
}

function updateJimpitan(token, id, data) {
  try {
    var session = requireAuth(token, 'jimpitan', 2);
    validateRequired(data, ['nominal', 'status', 'metode']);
    if (!isValidNumberValue(data.nominal)) throw userError('Nominal harus berupa angka.');
    var existing = findObjectById(SHEET_NAMES.JIMPITAN, id);
    if (!existing) return errorResponse('Data jimpitan tidak ditemukan.');
    updateObjectById(SHEET_NAMES.JIMPITAN, id, {
      nominal: Number(data.nominal), metode: data.metode, status: data.status,
      keterangan: data.keterangan || '', updated_at: timestampNow()
    });
    logActivity(session.username, 'Ubah', 'Jimpitan', session.nama + ' mengubah jimpitan ' + existing.nama_kepala_keluarga + ' tanggal ' + existing.tanggal);
    return successResponse({}, 'Data jimpitan berhasil diperbarui.');
  } catch (e) {
    return handleServerError(e, 'updateJimpitan');
  }
}

function deleteJimpitan(token, id) {
  try {
    var session = requireAuth(token, 'jimpitan', 2);
    var existing = findObjectById(SHEET_NAMES.JIMPITAN, id);
    if (!existing) return errorResponse('Data jimpitan tidak ditemukan.');
    deleteObjectById(SHEET_NAMES.JIMPITAN, id);
    logActivity(session.username, 'Hapus', 'Jimpitan', session.nama + ' menghapus jimpitan ' + existing.nama_kepala_keluarga + ' tanggal ' + existing.tanggal);
    return successResponse({}, 'Data jimpitan berhasil dihapus.');
  } catch (e) {
    return handleServerError(e, 'deleteJimpitan');
  }
}

function getJimpitanBulanan(token, bulan) {
  try {
    requireAuth(token, 'jimpitan', 1);
    if (!bulan) bulan = todayString().substring(0, 7);
    var items = sheetToObjects(SHEET_NAMES.JIMPITAN).filter(function (j) {
      return String(j.tanggal).substring(0, 7) === bulan;
    });
    var activeKK = getActiveKepalaKeluarga_();
    var totalRumah = activeKK.length;

    var perHariMap = {};
    var perMingguMap = {};
    var setorKKSet = {};
    var totalNominal = 0;
    items.forEach(function (j) {
      var tgl = String(j.tanggal);
      perHariMap[tgl] = (perHariMap[tgl] || 0) + (Number(j.nominal) || 0);
      var tanggalNum = Number(tgl.split('-')[2]) || 1;
      var label = 'Minggu ke-' + Math.ceil(tanggalNum / 7);
      perMingguMap[label] = (perMingguMap[label] || 0) + (Number(j.nominal) || 0);
      totalNominal += Number(j.nominal) || 0;
      if (j.status === 'Lunas' || j.status === 'Sebagian') setorKKSet[j.no_kk] = true;
    });

    var perHari = Object.keys(perHariMap).sort().map(function (tgl) { return { tanggal: tgl, total: perHariMap[tgl] }; });
    var perMinggu = Object.keys(perMingguMap).sort().map(function (label) { return { minggu: label, total: perMingguMap[label] }; });
    var sudahSetor = Object.keys(setorKKSet).length;
    var belum = Math.max(0, totalRumah - sudahSetor);
    var rumahBelumTercatat = activeKK.filter(function (kk) { return !setorKKSet[kk.no_kk]; })
      .map(function (kk) { return { no_kk: kk.no_kk, nama: kk.nama }; });

    return successResponse({
      bulan: bulan, total_rumah: totalRumah, sudah_setor: sudahSetor, belum_setor: belum,
      total_nominal: totalNominal, per_hari: perHari, per_minggu: perMinggu,
      rumah_belum_tercatat: rumahBelumTercatat
    });
  } catch (e) {
    return handleServerError(e, 'getJimpitanBulanan');
  }
}
